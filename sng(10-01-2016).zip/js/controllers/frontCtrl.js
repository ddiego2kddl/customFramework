'use strict';

app.controller('frontCtrl', ['$scope', function($scope){
	
}]);