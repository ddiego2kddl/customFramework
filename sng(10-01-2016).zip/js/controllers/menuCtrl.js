'use strict';

app.controller('menuCtrl', ['$scope', function($scope){
	
	console.log("menuCtrl");
	
}]);