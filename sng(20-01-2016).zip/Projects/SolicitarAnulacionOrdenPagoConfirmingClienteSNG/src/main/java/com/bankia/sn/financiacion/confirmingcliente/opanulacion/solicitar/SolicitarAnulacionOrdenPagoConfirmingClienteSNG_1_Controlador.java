package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar;

import com.bankia.bisa.sn.SNException;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades.AbstractControladorSNG_1;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades.ConstantesSNG_1;
import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.context.IContextoSN;
import es.cajamadrid.servicios.SN.SolicitarAnulacionOrdenPagoConfirmingClienteSNG.SolicitarAnulacionOrdenPagoConfirmingClienteSNG;

public class SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador
		extends AbstractControladorSNG_1 {

	@Override
	public void transformar(final IContextoSN contextoSN) {
		try {

			generarTrazaDebug(String.format(
					ConstantesSNG_1.DEBUG_INICIO_TRANSFORMAR,
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					this.getClass().getSimpleName()));

			final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio = (SolicitarAnulacionOrdenPagoConfirmingClienteSNG) contextoSN
					.getServicioNegocio();

			transformar(servicioNegocio);

			generarTrazaDebug(String.format(
					ConstantesSNG_1.DEBUG_FIN_TRANSFORMAR,
					Thread.currentThread().getStackTrace()[1].getMethodName(),
					this.getClass().getSimpleName()));
		}


		catch (final Exception e) {
			throwSNException(e.getMessage(),
					ConstantesSNG_1.COD_ERROR_GENERICO, this.getClass()
							.getSimpleName());
		}
	}

	public void transformar(
			final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio)
			throws WIException {

		validarCamposEntradaObligatorios(servicioNegocio);
	}

	private void validarCamposEntradaObligatorios(
			final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio) {

		/* 
		try {
			if (esVacio(servicioNegocio.getreferenciaExpediente())) {
				throwSNException(String.format(
						ConstantesSNG_1.DES_ERROR_PARAM_ENTRADA,
						ConstantesSNG_1.PARAM_REF_EXP),
						obtenerCodigoErrorGenericoSNG(), this.getClass()
								.getName());
			}
		}

		catch (SNException e) {
			throwSNException(e);
		}*/
	}

	@Override
	public void errorInvocacionSNG(final Exception e,
			final String idUnicoServicioNegocio) throws SNException {

		if (e instanceof WIException) {
			final WIException wi = (WIException) e;

			final String mensajeClaseError = new StringBuilder()
					.append("Error al ejecutar servicio ")
					.append(wi.getService_name())
					.append("Cod. Error WIException ")
					.append(wi.getErrorCode())
					.append("  Mensaje WIException: ").append(wi.getMessage())
					.toString();

			final WIException wiException = new WIException(wi.getMessage(),
					wi.getSubsystem(), ConstantesSNG_1.COD_ERROR_GENERICO);

			eliminarReferenciaServicioNegocio(idUnicoServicioNegocio);
			throwSNException(wiException, "", "", mensajeClaseError);
		} else if (e instanceof SNException) {
			eliminarReferenciaServicioNegocio(idUnicoServicioNegocio);
			throwSNException(e);
		} else {
			eliminarReferenciaServicioNegocio(idUnicoServicioNegocio);
			throwSNException(e.getMessage(), obtenerCodigoErrorGenericoSNG(),
					"");
		}
	}

	@Override
	public String obtenerCodigoErrorGenericoSNG() {
		return ConstantesSNG_1.COD_ERROR_GENERICO;
	}

}