package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar;

import com.bankia.bisa.sn.transformer.TransformerBaseIn;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades.AbstractControladorSNG_1;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades.ConstantesSNG_1;
import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.context.IContextoSN;
import es.cajamadrid.servicios.CM.CMPMM070_INS.CMPMM070_INS;
import es.cajamadrid.servicios.CM.CMPMM070_INS.StructCabeceraAplicacionCMPMM070_INS;
import es.cajamadrid.servicios.SN.SolicitarAnulacionOrdenPagoConfirmingClienteSNG.SolicitarAnulacionOrdenPagoConfirmingClienteSNG;

public class SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_TransformIn_CMPMM070_INS
		extends TransformerBaseIn {

	@Override
	public void transformar(final IContextoSN contextoSN) {

		AbstractControladorSNG_1.generarTrazaDebug(String.format(
				ConstantesSNG_1.DEBUG_INICIO_TRANSFORMAR, Thread
						.currentThread().getStackTrace()[1].getMethodName(),
				this.getClass().getSimpleName()));

		final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio = (SolicitarAnulacionOrdenPagoConfirmingClienteSNG) contextoSN
				.getServicioNegocio();

		final CMPMM070_INS servicioIT = obtenerNuevaInstanciaCMPMM070_INS();

		contextoSN.setCurrentItService(servicioIT);

		super.transformCabeceraNegocio(contextoSN);

		transformar(servicioNegocio, servicioIT);

		AbstractControladorSNG_1.generarTrazaDebug(String.format(
				ConstantesSNG_1.DEBUG_FIN_TRANSFORMAR, Thread.currentThread()
						.getStackTrace()[1].getMethodName(), this.getClass()
						.getSimpleName()));
	}

	private CMPMM070_INS obtenerNuevaInstanciaCMPMM070_INS() {
		CMPMM070_INS servicioIT = null;

		try {
			servicioIT = new CMPMM070_INS();
		} catch (final WIException e) {
			AbstractControladorSNG_1.throwSNException(e, Thread.currentThread()
					.getStackTrace()[1].getMethodName(),
					ConstantesSNG_1.COD_ERROR_GENERICO);
		}

		return servicioIT;
	}

	public void transformar(
			final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio,
			final CMPMM070_INS servicioIT) {
		try {
			cargarCabeceraAplicacion(servicioIT, servicioNegocio);
			cargarParteEspecifica(servicioNegocio, servicioIT);

		} catch (final WIException e) {
			AbstractControladorSNG_1.throwSNException(e,
					"transformar() - TransformIn_CMPMM070_INS",
					ConstantesSNG_1.COD_ERROR_GENERICO);
		}
	}

	private void cargarCabeceraAplicacion(CMPMM070_INS servicioIT,
			SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioSNG) {

		StructCabeceraAplicacionCMPMM070_INS cabAplicacion = new StructCabeceraAplicacionCMPMM070_INS();
		servicioIT.setcabeceraAplicacion(cabAplicacion);
	}

	private void cargarParteEspecifica(
			final SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio,
			final CMPMM070_INS servicioIT) throws WIException {
		
		//Setear servioIT en Servicio de negocio -Ejemplo-
		//servicioIT.setNumeroDeExpedientenuexp2(Utilidades.parseStringToLong(servicioNegocio.getreferenciaExpediente()));
		
	}

}