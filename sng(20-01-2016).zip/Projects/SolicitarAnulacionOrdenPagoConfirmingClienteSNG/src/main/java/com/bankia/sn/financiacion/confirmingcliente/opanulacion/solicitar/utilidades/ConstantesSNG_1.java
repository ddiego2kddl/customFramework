package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades;

public abstract class ConstantesSNG_1 {

	// Errores
	public static final String COD_ERROR_GENERICO = "EG0001";
	public static final String COD_ERROR_PTE = "PTE";

	public static final String DES_ERROR_OBTENER_DETALLE = "No ha sido posible obtener el detalle del documento de la cartera pendiente del cliente confirming";
	public static final String DES_ERROR_PARAM_ENTRADA = "El campo %s es obligatorio";
	public static final String DES_ERROR_FORMATO_NUMERICO_INVALIDO = "El campo referencia expediente tiene forma";
	public static final String DES_ERROR_NUM_INTER_DOC = "El campo numero interno documento es obligatorio";
	public static final String DES_ERROR_PARAM_ENTRADA_REF_EXP = "El campo referencia expediente es obligatorio";
	public static final String DES_ERROR_FORMATO_IMPORTE_INVALIDO = "El formato del importe es invalido";
	public static final String DES_ERROR_FORMATO_FECHA_INVALIDO = "El formato de la fecha es invalido";
	public static final String DES_ERROR_FORMATO_PORCENTAJE_INVALIDO = "El formato del porcentaje es invalido";
	public static final String DES_ERROR_FORMATO_CANTIDAD_DECIMAL_INVALIDO = "El formato de la cantidad decimal es invalido";
	public static final String DES_ERROR_FORMATO_CARACTER_INVALIDO = "El formato del caracter es invalido";
	public static final String DES_ERROR_FORMATO_CODIGO_INTERNACIONAL_CUENTA_BANCARIA_INVALIDO = "El formato del código internacional de cuenta bancaria es invalido";


	// Mensajes de log
	public static final String DEBUG_INICIO_TRANSFORMAR = "Inicio %s -> %s";
	public static final String DEBUG_FIN_TRANSFORMAR = "Fin %s -> %s";

	// Parámetros entrada
	public static final String PARAM_NUM_INTER_DOC = "numero interno documento";
	public static final String PARAM_REF_EXP = "referencia expediente";

	// Parte específica
	public static final Character INDICADOR_OIE_NOSINANOS = 'O';
	public static final Character INDICADOR_CONTROL = 'N';

	// Funciones
	public static final char DIGITO_CONTROL_DIVISA = '1';

}