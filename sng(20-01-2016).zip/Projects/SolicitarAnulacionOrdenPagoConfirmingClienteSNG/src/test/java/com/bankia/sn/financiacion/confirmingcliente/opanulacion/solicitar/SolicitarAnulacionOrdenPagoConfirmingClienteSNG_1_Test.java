package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar;

import static org.junit.Assert.assertTrue;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import com.bankia.bisa.sn.SNException;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.exception.SNExpectedException;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.resources.CMPMM070_Mock;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.resources.WiServiceClassMock;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.test.SNTestHelper;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.test.SNTestHelperImpl;
import com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.utilidades.ConstantesSNG_1;
import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.context.ContextSN;
import com.gfi.webIntegrator.context.IContextoSN;

import es.cajamadrid.servicios.SN.SolicitarAnulacionOrdenPagoConfirmingClienteSNG.SolicitarAnulacionOrdenPagoConfirmingClienteSNG;

public class SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Test {

	private static SNTestHelper testHelper;
	private static SolicitarAnulacionOrdenPagoConfirmingClienteSNG servicioNegocio;
	private static SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador controlador;

	@Resource
	private static ContextSN contexto;

	//private static final String obligatorio_referenciaExp = "El campo referenciaExpediente es obligatorio";

	private static final String METHOD_SIN_RELLAMADA = "sin_Rellamada_OK";
	private static final String METHOD_CON_RELLAMADA = "con_Rellamada_OK";

	@Rule
	public SNExpectedException excepcionEsperada = SNExpectedException.none();

	@BeforeClass
	public static void iniciarContexto() throws Exception {
		controlador = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador();
		servicioNegocio = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG();
		testHelper = new SNTestHelperImpl(servicioNegocio, 1);
		contexto = Mockito.mock(ContextSN.class);
	}

	@Before
	public void iniciarDatosEntradaSN() throws WIException {
		darValoresCorrectosEntradaSNG();
	}

	public void darValoresCorrectosEntradaSNG() throws WIException {
		//SETEAR DATOS DE ENTRADA, PEDIR DATOS A MADRID PARA PASAR PRUEBA DE INTEGRACION O BUSCAR EN OI1
		//servicioNegocio.setreferenciaExpediente("24214");
	}

	//TEST CAMPO NULO
	/*
	@Test
	public void referenciaExp_nulo() throws Exception {
		excepcionEsperada.tieneCodigoErrorYMensajeContiene(
				ConstantesSNG_1.COD_ERROR_GENERICO, obligatorio_referenciaExp);

		servicioNegocio.setreferenciaExpediente(null);
		testHelper.ejecutarTest(true);
	}
	*/

	@Test
	public void ejecucionSinRellamada() throws Exception {

		testHelper.setPrimerPaso(CMPMM070_Mock.class, METHOD_SIN_RELLAMADA);
		testHelper.ejecutarTest(true);

		assertTrue(testHelper.seHanEjecutadoTodosLosPasos());
	}

	@Test
	public void ejecucionConRellamada() throws Exception {

		testHelper.setPrimerPaso(CMPMM070_Mock.class, METHOD_CON_RELLAMADA);
		testHelper.ejecutarTest(true);

		assertTrue(testHelper.seHanEjecutadoTodosLosPasos());
	}

	@Ignore
	@Test
	public void ejecutarPruebaIntegrada() {
		testHelper.ejecutarTestIntegrado();
	}

	@Test(expected = SNException.class)
	public void testTransformarIContextoSN_nulo() {
		IContextoSN contexto = null;
		controlador.transformar(contexto);
	}

	@Test(expected = SNException.class)
	public void testTransformarIContextoSN_SN_nulo() {
		Mockito.when(contexto.getServicioNegocio()).thenReturn(null);
		controlador.transformar(contexto);
	}

	@Test(expected = SNException.class)
	public void testTransformarIContextoSN_SN_cast_error() throws WIException {
		Mockito.when(contexto.getServicioNegocio()).thenReturn(
				new WiServiceClassMock());
		controlador.transformar(contexto);
	}
	
	@Test(expected = SNException.class)
	public void testWIException() {
		controlador = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador();
		WIException e = new WIException("test");
		controlador.errorInvocacionSNG(e, "1");
	}
	
	@Test(expected = SNException.class)
	public void testSNException() {
		controlador = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador();
		SNException e = new SNException("test");
		controlador.errorInvocacionSNG(e, "1");
	}
	
	@Test(expected = SNException.class)
	public void testException() {
		controlador = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador();
		Exception e = new Exception("test");
		controlador.errorInvocacionSNG(e, "1");
	}
	
	@Test(expected = SNException.class)
	public void testExceptionCODE() {
		controlador = new SolicitarAnulacionOrdenPagoConfirmingClienteSNG_1_Controlador();
		WIException e = new WIException("test");
		e.setErrorCode(ConstantesSNG_1.COD_ERROR_PTE);
		controlador.errorInvocacionSNG(e, "1");
	}

}