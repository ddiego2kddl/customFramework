package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.resources;

import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.WIService;

import es.cajamadrid.servicios.CM.CMPMM070_INS.CMPMM070_INS;

public class CMPMM070_Mock {

	public WIService sin_Rellamada_OK(final CMPMM070_INS servicioIT)
			throws WIException {

		//servicioIT.setCodFinPaginacSNcofipa(ConstantesSNG_1.INDICADOR_NO_MAS);
		//servicioIT.setTablaCarterastabca1(componerTablaCarteras(false));

		return servicioIT;
	}
	
	public WIService con_Rellamada_OK(final CMPMM070_INS servicioIT)
			throws WIException {

		//servicioIT.setCodFinPaginacSNcofipa(ConstantesSNG_1.INDICADOR_NO_MAS);
		//servicioIT.setTablaCarterastabca1(componerTablaCarteras(true));

		return servicioIT;
	}
	
	//CAMBIAR TIPO DEL VECTOR, Y SETEAR CON LOS CAMPOS CORRESPONDIENTES --> REFERENCIA TRANSFORM_OUT
/*	private VectorCMPMM070_INS_TablaCarterastabca1 componerTablaCarteras(
			boolean rellamada) throws WIException {
		int numeroCarteras = 10;
		final VectorCMPMM070_INS_TablaCarterastabca1 vectorGrupo = new VectorCMPMM070_INS_TablaCarterastabca1();

		if (rellamada) {
			numeroCarteras = 15;
		}

		for (int i = 0; i < numeroCarteras; i++) {
			StructCMPMM070_INS_TablaCarterastabca1 structGrupo = new StructCMPMM070_INS_TablaCarterastabca1();

			structGrupo.setFechaVencimientofevto0BISA(Utilidades.crearFechaBisa("2015-02-01"));
			structGrupo.setTipoVencimientocotven('a');
			structGrupo.setImpTotalOrdenesPagoimtoo1BISA(Utilidades.crearImporteBisa(2400,'2'));
			
			vectorGrupo.add(structGrupo);
		}

		return vectorGrupo;
	}*/
	
}