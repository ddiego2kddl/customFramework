package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.resources;

import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.WIService;

public class WiServiceClassMock extends WIService {
	public WiServiceClassMock(String aModule, String aName) throws WIException {
		super(aModule, aName);
	}

	public WiServiceClassMock() throws WIException {
		super(null, null);
	}
}