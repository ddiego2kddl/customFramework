package com.bankia.sn.financiacion.confirmingcliente.opanulacion.solicitar.test;

import com.gfi.webIntegrator.WIException;
import com.gfi.webIntegrator.WIService;

public class EscenarioSN {

	private WIService servicioIT;
	private Class<?> claseParaObtenerServicioIT;
	private String nombreMetodoParaObtenerServicioIT;

	private WIException wiException;

	public Class<?> getClaseParaObtenerServicioIT() {
		return claseParaObtenerServicioIT;
	}

	public void setClaseParaObtenerServicioIT(
			final Class<?> claseParaObtenerServicioIT) {
		this.claseParaObtenerServicioIT = claseParaObtenerServicioIT;
	}

	public String getNombreMetodoParaObtenerServicioIT() {
		return nombreMetodoParaObtenerServicioIT;
	}

	public void setNombreMetodoParaObtenerServicioIT(
			final String nombreMetodoParaObtenerServicioIT) {
		this.nombreMetodoParaObtenerServicioIT = nombreMetodoParaObtenerServicioIT;
	}

	public WIService getServicioIT() {
		return servicioIT;
	}

	public void setServicioIT(final WIService servicioIT) {
		this.servicioIT = servicioIT;
	}

	public WIException getWiException() {
		return wiException;
	}

	public void setWiException(final String errorCode) {
		this.wiException = new WIException("", "", errorCode);
	}

	public void setWiException(final String errorCode,
			final String mensajeWiException) {
		this.wiException = new WIException(mensajeWiException, "", errorCode);
	}

	@Override
	public String toString() {
		return "EscenarioSN [servicioIT=" + servicioIT
				+ ", claseParaObtenerServicioIT=" + claseParaObtenerServicioIT
				+ ", nombreMetodoParaObtenerServicioIT="
				+ nombreMetodoParaObtenerServicioIT + ", wiException="
				+ wiException + "]";
	}

}