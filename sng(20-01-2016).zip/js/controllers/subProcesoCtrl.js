'use strict';

app.controller('subProcesoCtrl', ['$scope', function($scope){
    
}]);