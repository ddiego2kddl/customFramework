'use strict'

app.service('frontService', function (utilsService,$http,$rootScope) {

 
});

